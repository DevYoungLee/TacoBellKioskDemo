package com.youngmlee.tacobellkiosk.viewModel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.MutableLiveData;
import android.support.annotation.NonNull;
import android.util.Log;

import com.youngmlee.tacobellkiosk.data.Callback;
import com.youngmlee.tacobellkiosk.data.Repository;
import com.youngmlee.tacobellkiosk.data.RepositoryImpl;
import com.youngmlee.tacobellkiosk.data.model.MenuCategory;

import java.util.List;

public class OrderActivityViewModel extends AndroidViewModel {

    private static final String TAG = "retrieving_data";

    private MutableLiveData<List<MenuCategory>> menuCategoryListLiveData;
    private Repository repository;

    public OrderActivityViewModel(@NonNull Application application) {
        super(application);
        repository = new RepositoryImpl();
    }

    public MutableLiveData<List<MenuCategory>> getMenuCategoryList(){
        if (menuCategoryListLiveData == null) {
            menuCategoryListLiveData = new MutableLiveData<>();
            repository.getMenuCategories(new Callback<List<MenuCategory>>() {
                @Override
                public void onSuccess(List<MenuCategory> menuCategoryList) {
                    menuCategoryListLiveData.postValue(menuCategoryList);
                }

                @Override
                public void onFailure(String message) {
                    Log.d(TAG, "Retrieving data failed: " + message);
                }
            });
        }
        return menuCategoryListLiveData;
    }


}
