package com.youngmlee.tacobellkiosk.data.model;

import java.util.List;

public class MenuCategory {
    private String categoryName;
    private List<MenuItem> menuItemList;

    public MenuCategory(String categoryName, List<MenuItem> menuItemList){
        this.categoryName = categoryName;
        this.menuItemList = menuItemList;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setMenuItemList(List<MenuItem> menuItemList) {
        this.menuItemList = menuItemList;
    }

    public List<MenuItem> getMenuItemList() {
        return menuItemList;
    }
}
