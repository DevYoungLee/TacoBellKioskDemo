package com.youngmlee.tacobellkiosk.data;

import com.youngmlee.tacobellkiosk.data.model.MenuCategory;

import java.util.List;

public interface Repository {
    void getMenuCategories(final Callback<List<MenuCategory>> callback);
}
