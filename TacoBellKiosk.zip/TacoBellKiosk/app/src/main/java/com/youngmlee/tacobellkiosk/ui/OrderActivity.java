package com.youngmlee.tacobellkiosk.ui;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.youngmlee.tacobellkiosk.R;
import com.youngmlee.tacobellkiosk.viewModel.OrderActivityViewModel;

import androidx.lifecycle.ViewModelProviders;

public class OrderActivity extends AppCompatActivity {

    private OrderActivityViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        viewModel = ViewModelProviders.of(this).get(OrderActivityViewModel.class);
        setContentView(R.layout.activity_order);

    }
}
