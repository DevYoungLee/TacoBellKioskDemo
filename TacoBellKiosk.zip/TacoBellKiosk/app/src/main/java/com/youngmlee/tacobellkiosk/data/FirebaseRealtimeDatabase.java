package com.youngmlee.tacobellkiosk.data;

import android.support.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.youngmlee.tacobellkiosk.data.model.Menu;

public class FirebaseRealtimeDatabase implements Database {

    private DatabaseReference databaseReference;

    public FirebaseRealtimeDatabase(){
        databaseReference = FirebaseDatabase.getInstance().getReference();
    }

    @Override
    public void getMenu(final Callback<Menu> menuCallback){
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Menu menu = dataSnapshot.getValue(Menu.class);
                menuCallback.onSuccess(menu);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                menuCallback.onFailure(databaseError.getMessage());
            }
        });
    }
}
