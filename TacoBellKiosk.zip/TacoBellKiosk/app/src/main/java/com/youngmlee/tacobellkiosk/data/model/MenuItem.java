package com.youngmlee.tacobellkiosk.data.model;

public class MenuItem {
    private String name;
    private String cal;
    private double price;
    private String image;

    public MenuItem(String name, String cal, double price, String image){
        this.name = name;
        this.cal = cal;
        this.price = price;
        this.image = image;
    }
}
