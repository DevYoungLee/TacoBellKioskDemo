package com.youngmlee.tacobellkiosk.data;

import com.youngmlee.tacobellkiosk.data.model.Menu;
import com.youngmlee.tacobellkiosk.data.model.MenuCategory;

import java.util.List;

public class RepositoryImpl implements Repository {

    public Database database;

    public RepositoryImpl(){
        this.database = new FirebaseRealtimeDatabase();
    }

    @Override
    public void getMenuCategories(final Callback<List<MenuCategory>> callback) {
        database.getMenu(new Callback<Menu>() {
            @Override
            public void onSuccess(Menu menu) {
                callback.onSuccess(menu.getMenuCategoryList());
            }

            @Override
            public void onFailure(String message) {
                callback.onFailure(message);
            }
        });
    }
}
