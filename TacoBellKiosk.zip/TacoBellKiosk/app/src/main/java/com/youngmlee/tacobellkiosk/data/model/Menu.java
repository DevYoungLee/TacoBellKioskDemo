package com.youngmlee.tacobellkiosk.data.model;

import java.util.List;

public class Menu {
    private String menuName;
    private List<MenuCategory> menuCategoryList;

    public Menu(String menuName, List<MenuCategory> menuCategoryList){
        this.menuName = menuName;
        this.menuCategoryList = menuCategoryList;
    }

    public void setMenuName(String menuName) {
        this.menuName = menuName;
    }

    public String getMenuName() {
        return menuName;
    }

    public void setMenuCategoryList(List<MenuCategory> menuCategoryList) {
        this.menuCategoryList = menuCategoryList;
    }

    public List<MenuCategory> getMenuCategoryList() {
        return menuCategoryList;
    }
}
